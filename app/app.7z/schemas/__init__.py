from .document_type_schema import DocumentTypeSchema
from .issuing_body_schema import IssuingBodySchema
from .recipient_schema import DispatchRecipientSchema
from .processor_schema import DispatchProcessorSchema
from .follower_schema import DispatchFollowerSchema
from .attachment_schema import DispatchAttachmentSchema
from .comment_schema import DispatchCommentSchema
from .view_schema import DispatchViewSchema
from .dispatch_schema import DispatchSchema

__all__ = [
    "DocumentTypeSchema",
    "IssuingBodySchema",
    "DispatchRecipientSchema",
    "DispatchProcessorSchema",
    "DispatchFollowerSchema",
    "DispatchAttachmentSchema",
    "DispatchCommentSchema",
    "DispatchViewSchema",
    "DispatchSchema",
]
