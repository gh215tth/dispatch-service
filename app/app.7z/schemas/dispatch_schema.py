from marshmallow import Schema, fields, validate

class DispatchSchema(Schema):
    dispatch_id = fields.UUID(dump_only=True)
    document_number = fields.Str(required=True, validate=validate.Length(min=1, max=100))
    summary = fields.Str(allow_none=True)
    page_count = fields.Int(allow_none=True, validate=validate.Range(min=1))
    
    security_level = fields.Str(
        required=True,
        validate=validate.OneOf(['public', 'internal', 'confidential', 'top_secret'])
    )
    urgency_level = fields.Str(
        required=True,
        validate=validate.OneOf(['normal', 'urgent', 'immediate'])
    )
    processing_status = fields.Str(
        required=True,
        validate=validate.OneOf(['pending', 'in_progress', 'completed', 'archived'])
    )

    document_type_id = fields.UUID(required=True)
    issuing_body_id = fields.UUID(required=True)
    creator_user_id = fields.UUID(required=True)
    approver_user_id = fields.UUID(allow_none=True)

    arrival_timestamp = fields.DateTime(allow_none=True)
    effective_timestamp = fields.DateTime(allow_none=True)
    expiration_timestamp = fields.DateTime(allow_none=True)
    approved_at = fields.DateTime(allow_none=True)

    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)
