from flask import jsonify, request, abort
from app.schemas.dispatch_schema import DispatchAttachmentSchema
from app.services import AttachmentService, DispatchService

attachment_schema = DispatchAttachmentSchema()
attachments_schema = DispatchAttachmentSchema(many=True)


def list_attachments(dispatch_id):
    if not DispatchService.get_by_id(dispatch_id):
        abort(404, "Dispatch not found")
    qs = AttachmentService.list_by_dispatch(dispatch_id)
    return jsonify(attachments_schema.dump(qs))


def create_attachment(dispatch_id):
    if not DispatchService.get_by_id(dispatch_id):
        abort(404, "Dispatch not found")
    payload = request.get_json() or {}
    errors = attachment_schema.validate(payload)
    if errors:
        return jsonify({"errors": errors}), 400
    a = AttachmentService.create(dispatch_id, payload)
    return jsonify(attachment_schema.dump(a)), 201


def delete_attachment(dispatch_id, drive_item_id):
    a = AttachmentService.delete(dispatch_id, drive_item_id)
    if not a:
        abort(404, "Attachment not found")
    return jsonify({"message": "deleted"})
