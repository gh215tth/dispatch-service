# app/controllers/__init__.py

from .dispatch_controller import *
from .document_type_controller import *
from .issuing_body_controller import *
from .recipient_controller import *
from .processor_controller import *
from .follower_controller import *
from .attachment_controller import *
from .comment_controller import *
from .view_controller import *
