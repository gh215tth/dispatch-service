from flask import Blueprint
from app.controllers.dispatch_controller import (
    list_dispatches, get_dispatch, create_dispatch, update_dispatch, delete_dispatch,
    list_document_types, get_document_type, create_document_type, update_document_type, delete_document_type,
    list_issuing_bodies, get_issuing_body, create_issuing_body, update_issuing_body, delete_issuing_body,
    list_recipients, create_recipient, delete_recipient,
    list_processors, create_processor, delete_processor,
    list_followers, create_follower, delete_follower,
    list_attachments, create_attachment, delete_attachment,
    list_comments, create_comment, update_comment, delete_comment,
    list_views, create_view, delete_view
)

dispatch_bp = Blueprint("dispatch", __name__, url_prefix="/api/v1/dispatches")
document_type_bp = Blueprint("document_type", __name__, url_prefix="/api/v1/document_types")
issuing_body_bp = Blueprint("issuing_body", __name__, url_prefix="/api/v1/issuing_bodies")
recipient_bp = Blueprint("recipient", __name__, url_prefix="/api/v1/dispatches/<dispatch_id>/recipients")
processor_bp = Blueprint("processor", __name__, url_prefix="/api/v1/dispatches/<dispatch_id>/processors")
follower_bp = Blueprint("follower", __name__, url_prefix="/api/v1/dispatches/<dispatch_id>/followers")
attachment_bp = Blueprint("attachment", __name__, url_prefix="/api/v1/dispatches/<dispatch_id>/attachments")
comment_bp = Blueprint("comment", __name__, url_prefix="/api/v1/dispatches/<dispatch_id>/comments")
view_bp = Blueprint("view", __name__, url_prefix="/api/v1/dispatches/<dispatch_id>/views")

# Error handlers
for bp in [dispatch_bp, document_type_bp, issuing_body_bp, recipient_bp, processor_bp, follower_bp, attachment_bp, comment_bp, view_bp]:
    @bp.errorhandler(400)
    def bad_request(error):
        return jsonify({"error": str(error.description)}), 400

    @bp.errorhandler(404)
    def not_found(error):
        return jsonify({"error": str(error.description)}), 404

# Dispatch routes
@dispatch_bp.route("/", methods=["GET"])
def _list():
    return list_dispatches()

@dispatch_bp.route("/", methods=["POST"])
def _create():
    return create_dispatch()

@dispatch_bp.route("/<dispatch_id>", methods=["GET"])
def _get(dispatch_id):
    return get_dispatch(dispatch_id)

@dispatch_bp.route("/<dispatch_id>", methods=["PUT", "PATCH"])
def _update(dispatch_id):
    return update_dispatch(dispatch_id)

@dispatch_bp.route("/<dispatch_id>", methods=["DELETE"])
def _delete(dispatch_id):
    return delete_dispatch(dispatch_id)

# DocumentType routes
@document_type_bp.route("/", methods=["GET"])
def _list_document_types():
    return list_document_types()

@document_type_bp.route("/", methods=["POST"])
def _create_document_type():
    return create_document_type()

@document_type_bp.route("/<document_type_id>", methods=["GET"])
def _get_document_type(document_type_id):
    return get_document_type(document_type_id)

@document_type_bp.route("/<document_type_id>", methods=["PUT", "PATCH"])
def _update_document_type(document_type_id):
    return update_document_type(document_type_id)

@document_type_bp.route("/<document_type_id>", methods=["DELETE"])
def _delete_document_type(document_type_id):
    return delete_document_type(document_type_id)

# IssuingBody routes
@issuing_body_bp.route("/", methods=["GET"])
def _list_issuing_bodies():
    return list_issuing_bodies()

@issuing_body_bp.route("/", methods=["POST"])
def _create_issuing_body():
    return create_issuing_body()

@issuing_body_bp.route("/<issuing_body_id>", methods=["GET"])
def _get_issuing_body(issuing_body_id):
    return get_issuing_body(issuing_body_id)

@issuing_body_bp.route("/<issuing_body_id>", methods=["PUT", "PATCH"])
def _update_issuing_body(issuing_body_id):
    return update_issuing_body(issuing_body_id)

@issuing_body_bp.route("/<issuing_body_id>", methods=["DELETE"])
def _delete_issuing_body(issuing_body_id):
    return delete_issuing_body(issuing_body_id)

# DispatchRecipient routes
@recipient_bp.route("/", methods=["GET"])
def _list_recipients(dispatch_id):
    return list_recipients(dispatch_id)

@recipient_bp.route("/", methods=["POST"])
def _create_recipient(dispatch_id):
    return create_recipient(dispatch_id)

@recipient_bp.route("/<user_id>", methods=["DELETE"])
def _delete_recipient(dispatch_id, user_id):
    return delete_recipient(dispatch_id, user_id)

# DispatchProcessor routes
@processor_bp.route("/", methods=["GET"])
def _list_processors(dispatch_id):
    return list_processors(dispatch_id)

@processor_bp.route("/", methods=["POST"])
def _create_processor(dispatch_id):
    return create_processor(dispatch_id)

@processor_bp.route("/<user_id>", methods=["DELETE"])
def _delete_processor(dispatch_id, user_id):
    return delete_processor(dispatch_id, user_id)

# DispatchFollower routes
@follower_bp.route("/", methods=["GET"])
def _list_followers(dispatch_id):
    return list_followers(dispatch_id)

@follower_bp.route("/", methods=["POST"])
def _create_follower(dispatch_id):
    return create_follower(dispatch_id)

@follower_bp.route("/<user_id>", methods=["DELETE"])
def _delete_follower(dispatch_id, user_id):
    return delete_follower(dispatch_id, user_id)

# DispatchAttachment routes
@attachment_bp.route("/", methods=["GET"])
def _list_attachments(dispatch_id):
    return list_attachments(dispatch_id)

@attachment_bp.route("/", methods=["POST"])
def _create_attachment(dispatch_id):
    return create_attachment(dispatch_id)

@attachment_bp.route("/<drive_item_id>", methods=["DELETE"])
def _delete_attachment(dispatch_id, drive_item_id):
    return delete_attachment(dispatch_id, drive_item_id)

# DispatchComment routes
@comment_bp.route("/", methods=["GET"])
def _list_comments(dispatch_id):
    return list_comments(dispatch_id)

@comment_bp.route("/", methods=["POST"])
def _create_comment(dispatch_id):
    return create_comment(dispatch_id)

@comment_bp.route("/<comment_id>", methods=["PUT", "PATCH"])
def _update_comment(comment_id):
    return update_comment(comment_id)

@comment_bp.route("/<comment_id>", methods=["DELETE"])
def _delete_comment(comment_id):
    return delete_comment(comment_id)

# DispatchView routes
@view_bp.route("/", methods=["GET"])
def _list_views(dispatch_id):
    return list_views(dispatch_id)

@view_bp.route("/", methods=["POST"])
def _create_view(dispatch_id):
    return create_view(dispatch_id)

@view_bp.route("/<view_id>", methods=["DELETE"])
def _delete_view(view_id):
    return delete_view(view_id)