# app/routes/__init__.py
from .dispatch_routes import (
    dispatch_bp, document_type_bp, issuing_body_bp, recipient_bp,
    processor_bp, follower_bp, attachment_bp, comment_bp, view_bp
)

def register_routes(app):
    app.register_blueprint(dispatch_bp)
    app.register_blueprint(document_type_bp)
    app.register_blueprint(issuing_body_bp)
    app.register_blueprint(recipient_bp)
    app.register_blueprint(processor_bp)
    app.register_blueprint(follower_bp)
    app.register_blueprint(attachment_bp)
    app.register_blueprint(comment_bp)
    app.register_blueprint(view_bp)